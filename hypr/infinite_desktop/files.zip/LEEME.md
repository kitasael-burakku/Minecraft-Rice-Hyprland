# Por qué se rompieron tus scripts (y qué arreglé)

Gemini tenía razón. Desde **Hyprland 0.55** (config en Lua), `hyprctl dispatch`
dejó de aceptar la sintaxis vieja de hyprlang (`dispatch togglefloating
address:0x...`). Ahora interpreta el argumento como una **expresión Lua real**
contra el namespace `hl.dsp.*`. No es un bug ni algo específico de tu
`hyprland.lua`: es intencional. Cuando alguien reportó justo este problema, el
mantenedor de Hyprland (vaxerski) contestó *"this is expected behavior"*, sin
capa de compatibilidad hacia atrás.

Sintaxis vieja (rota):
```
hyprctl dispatch togglefloating address:0x123
```
Sintaxis nueva:
```
hyprctl dispatch 'hl.dsp.window.float({ action = "toggle", window = "address:0x123" })'
```

## Qué cambié

Metí toda la lógica de "cómo hablarle a hyprctl" en un solo archivo nuevo,
**`hypr_ipc.py`**, y todos tus scripts lo importan en vez de armar los
comandos a mano. Así, si Hyprland vuelve a cambiar esto (viene pasando cada
pocas semanas), solo tocás un archivo.

Los 7 archivos quedaron así:
- `hypr_ipc.py` — **nuevo**, capa de compatibilidad.
- `discover_hyprland_api.sh` — **nuevo**, diagnóstico (ver abajo, importante).
- `floating_tile_toggle.py`, `move_window.py`, `move_window_tiled.py`,
  `navigate_windows.py`, `resize_window.py`, `infinite_desktop_core.py` —
  misma lógica, dispatch reescrito.
- `infinite-desktop.sh` — sin cambios, no llama a `dispatch` directamente.

Las llamadas de solo lectura (`hyprctl clients -j`, `activewindow -j`,
`monitors -j`, `getoption`) **no las toqué** — esas no pasan por el parser de
dispatch que cambió, así que deberían seguir funcionando igual.

## ⚠️ Un paso pendiente antes de confiar en esto al 100%

Para los dispatchers documentados en la wiki oficial (`togglefloating` →
`window.float`, `focuswindow` → `focus`, `movefocus`/`movewindow` con
dirección) la sintaxis nueva está confirmada y no debería haber sorpresas.

Pero **mover/redimensionar una ventana a coordenadas de píxel exactas**
(`moveactive exact X Y`, `movewindowpixel exact X Y,address:...`,
`resizewindowpixel exact W H,address:...`) — que es literalmente el corazón
de tu escritorio infinito — es API que Hyprland cambió hace muy pocas
semanas, y la wiki todavía no publica el nombre exacto del campo. Puse mi
mejor apuesta en dos funciones de `hypr_ipc.py`:

```python
def move_window_exact_lua(x, y, address):
    return (f'hl.dsp.window.move({{ window = "address:{address}", '
            f'coords = {{ {int(x)}, {int(y)} }}, mode = "exact" }})')

def resize_window_exact_lua(w, h, address):
    return (f'hl.dsp.window.resize({{ window = "address:{address}", '
            f'size = {{ {int(w)}, {int(h)} }}, mode = "exact" }})')
```

Antes de usar el escritorio infinito en serio, corré esto una vez (con una
ventana flotante abierta):

```bash
bash discover_hyprland_api.sh
```

Te lista los métodos reales que expone `hl.dsp.window` en tu instalación y
prueba mover/redimensionar la ventana activa, mostrando el error exacto si
el nombre de campo no es el correcto. Si falla, el mensaje te da 2-3
variantes para probar a mano (`x`/`y` sueltos en vez de `coords`, `position`
en vez de `coords`, etc.) — y solo tenés que corregir esas dos funciones en
`hypr_ipc.py`, todo lo demás ya les apunta a ellas.

Si querés pegarme la salida de ese script te ajusto el nombre del campo yo
mismo sin que tengas que tocar nada.
